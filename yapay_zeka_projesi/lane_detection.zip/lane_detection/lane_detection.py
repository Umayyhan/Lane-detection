import os
from cv2 import fillPoly
from matplotlib.colors import colorConverter
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import math
import cv2


def canny_function(image):
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    return cv2.Canny(blur,50,120)


def roi(image): 
    x = int(image.shape[1]) #x = 1920
    y = int(image.shape[0]) #y = 1073

    shape = np.array([[250, int(y)], [1800, int(y)], [int(0.55*x), int(0.6*y)], [int(0.45*x), int(0.6*y)]]) 
    # kose koordinatları = 250,1073 1750,1073 1056,643 864,643
    mask = np.zeros_like(image)
    cv2.fillPoly(mask, np.int32([shape]), 255)
    masked_image = cv2.bitwise_and(image, mask) #normal resim uzerine secili alan uygulanıyor.

    return masked_image #maskelenmis hali donuyor

def draw_line(line_image, x1, x2, color):
    cv2.line(line_image, (x1, int(0.60*line_image.shape[0])), (x2, int(line_image.shape[0])), color, 10)

def find_coordinates(line_image, avg_intercept, avg_slope):
    x1 = int((0.60*line_image.shape[0] - avg_intercept)/avg_slope)
    x2 = int((line_image.shape[0] - avg_intercept)/avg_slope)

    return x1,x2

def fill_lane(line_image, left_line_x1, left_line_x2, right_line_x1, right_line_x2):
        pts = np.array([[left_line_x1, int(0.60*line_image.shape[0])],
        [left_line_x2, int(line_image.shape[0])],[right_line_x2, int(line_image.shape[0])],
        [right_line_x1, int(0.60*line_image.shape[0])]], np.int32)

        cv2.fillPoly(line_image,[pts],(0,255,0))  

def draw_lines(line_image, lines):
    # global rightSlope, leftSlope, rightIntercept, leftIntercept
    rightSlope, leftSlope, rightIntercept, leftIntercept = [],[],[],[]
    #ortalamayı etkileyecek dış doğruların elenmesi işlemi
    #bulunan eğim ve y kesişim değerleri ile çizilecek noktalar bulunacak
    for line in lines:
        for x1,y1,x2,y2 in line:

            slope = (y1-y2)/(x1-x2)
            if slope > 0.57: # pozitif (sağ şeridin) yaklaşık eğimi  1750-1500 / 940
                if x1 > 500: #pozitif eğimde genellikle tespit edilen aralığa göre kayma yaratmaması için eklendi
                    yintercept = y2 - (slope*x2)
                    rightSlope.append(slope)
                    rightIntercept.append(yintercept)

            
            elif slope < -0.27: #negatif (sol şerit) yaklaşık eğim
                if x1 < 600: #negatif eğimde genellikle tespit edilen aralığa göre kayma yaratmaması için eklendi
                    yintercept = y2 - (slope*x2)  #y = mx+b              
                    leftSlope.append(slope)
                    leftIntercept.append(yintercept)

     #daha dogru sonuc icin son 30 degerin ortalamasını alıyoruz
    leftavgSlope = np.mean(leftSlope[-30:])
    leftavgIntercept = np.mean(leftIntercept[-30:]) 
    rightavgSlope = np.mean(rightSlope[-30:])
    rightavgIntercept = np.mean(rightIntercept[-30:])

    #ortalama eğim ve y ekseni kesim degerlerini kullanarak şeritlerin x1,y1 x2,y2 noktalarını buluyoruz ve çizdiriyoruz,
    # şeridin içini dolduruyoruz.
    left_line_x1, left_line_x2 = find_coordinates(line_image, leftavgIntercept, leftavgSlope)
    right_line_x1, right_line_x2 = find_coordinates(line_image, rightavgIntercept, rightavgSlope)

    fill_lane(line_image, left_line_x1, left_line_x2, right_line_x1, right_line_x2) 
    draw_line(line_image, left_line_x1,left_line_x2, (255,0,0))
    draw_line(line_image, right_line_x1,right_line_x2, (0,0,255))
    
    return line_image
    

cap = cv2.VideoCapture("test_video.mp4")
frame_counter = 0;

while(cap.isOpened()):
    _, frame = cap.read()
    frame_counter += 1
    canny_image = canny_function(frame)
    cropped_image = roi(canny_image)
    lines = cv2.HoughLinesP(cropped_image, 1, np.pi/180, 10, np.array([]), minLineLength=20, maxLineGap=100)
    line_image = np.zeros_like(frame)
    detected_lane = draw_lines(line_image,lines)
    combo_image = cv2.addWeighted(frame , 0.8, detected_lane, 1, 1)
    cv2.imshow("result", combo_image)
    if cv2.waitKey(1) & 0xFF == ord('q') : 
        break
    if frame_counter == int(cap.get(cv2.CAP_PROP_FRAME_COUNT)): #video sonu çıkış işlemi
        print("Videonun sonuna gelindi!")
        break
    cv2.waitKey(1)


cap.release()
cv2.destroyAllWindows()


